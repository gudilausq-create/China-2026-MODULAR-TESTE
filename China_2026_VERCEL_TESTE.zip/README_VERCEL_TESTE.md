# China 2026 — Teste Modular para Vercel

Pacote de teste estático. Não é a publicação definitiva.

Estrutura:
- index.html — entrada do aplicativo
- assets/core — artes principais
- destinos/index.html — catálogo de destinos
- destinos/xangai.html — entrada de Xangai
- destinos/xangai-*.html — módulos de Xangai

O pacote deve ser publicado mantendo a estrutura de pastas intacta.
