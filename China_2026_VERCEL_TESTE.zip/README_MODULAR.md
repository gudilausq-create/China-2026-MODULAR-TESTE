# China 2026 — Estrutura Modular — TESTE V3

## O que esta versão testa
- Central de Comando no `index.html` principal.
- `Central de Comando → Destinos / Roteiros` abre o módulo externo `destinos/index.html`.
- `Destinos / Roteiros → Xangai` abre `destinos/xangai.html`.
- Xangai possui 7 módulos: mapa, atrações, alternativas, comidas, onde provar, experiências gastronômicas e vídeos.
- Cada módulo pode ter uma ou várias telas sem alterar a arquitetura principal.
- Imagens ficam separadas em `assets/`.
- Endereços que aparecem como texto têm controles de COPIAR E COLAR nos módulos que os utilizam.

## Teste recomendado
Publicar temporariamente em um serviço de hospedagem estática para testar no Safari/iPhone. O app Arquivos não executa corretamente esta estrutura como site.
